document.addEventListener('click', function(evt) {
	if (evt.target.href && evt.target.href.split('?')[1].endsWith("REFINE_VIDEO")) {
		evt.preventDefault();
		evt.stopPropagation();
		chrome.extension.sendMessage({command: 'play_here', url: evt.target.href}, function(response) {});
	}
});
document.documentElement.setAttribute('clean-media-page-extension-installed', true);
var isInstalled = document.documentElement.getAttribute('clean-media-page-extension-installed');
console.log('clean-media-page-extension-installed = ' + isInstalled);
