chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
	// dispatch based on command
	if (request.command == 'play_here') {
		var playerUrl = chrome.extension.getURL("player.html") + "#" + request.url;
		chrome.tabs.create({ url: playerUrl });
	}
});

chrome.webRequest.onBeforeRequest.addListener(
	function(info) {
		// if (info.url.split("?")[0].split("#")[0].endsWith("m3u8") && info.type == "main_frame") {
		if (!info.url) return;
		if (!info.url.split("?")[1]) return;
		if (info.url.split("?")[1].split("#")[0].endsWith("REFINE_VIDEO") && info.type == "main_frame") {
			// var playerUrl = chrome.extension.getURL("player.html") + "#" + (info.url.split("#")[1] ? info.url.split("#")[1] : info.url).replace(/[?#&]\bREFINE_VIDEO\b/, '');
			var playerUrl = chrome.extension.getURL("player.html") + "#";
			playerUrl = playerUrl + (info.url.split("?")[1] ? info.url.split("?")[1] : info.url.split("#")[1] ? info.url.split("#")[1] : info.url);
			playerUrl = playerUrl.replace(/[?#&]\bREFINE_VIDEO\b/, '');
			return { redirectUrl:  playerUrl };
		}
	},
	{urls: ["<all_urls>"]},
	["blocking"]
);
