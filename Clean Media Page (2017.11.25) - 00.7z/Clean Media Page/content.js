document.addEventListener('click', function(evt) {
	if (evt.target.href && evt.target.href.split('?')[1].endsWith("REFINE_VIDEO")) {
		evt.preventDefault();
		evt.stopPropagation();
		chrome.extension.sendMessage({command: 'play_here', url: evt.target.href}, function(response) {});
	}
});